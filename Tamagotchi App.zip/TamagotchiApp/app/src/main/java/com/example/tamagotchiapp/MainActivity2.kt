package com.example.tamagotchiapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView

class MainActivity2 : AppCompatActivity() {
    private var petHunger = 60
    private var petHealth = 100
    private var petClean = 50

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // Set Buttons And Text Views
        val playButton = findViewById<Button>(R.id.playButton)
        val feedButton = findViewById<Button>(R.id.feedButton)
        val cleanButton = findViewById<Button>(R.id.cleanButton)
        val textHappy = findViewById<EditText>(R.id.textHappy)
        val textHunger = findViewById<EditText>(R.id.textHunger)
        val textClean = findViewById<EditText>(R.id.textClean)
        val petImage = findViewById<ImageView>(R.id.image4)

        // Set The Initial Text Values
        textHappy.setText(petHunger.toString())
        textHappy.setText(petClean.toString())
        textHappy.setText(petHealth.toString())

        // Handle Button Clicks
        feedButton.setOnClickListener{
            petHunger += 10
            petClean += 10
            petHealth += 5
            textHunger.setText(petClean.toString())
            animateImageChange(petImage,R.drawable.image3)
        }

        cleanButton.setOnClickListener {
            petClean += 10
            petHealth += 10
            textClean.setText(petClean.toString())
            animateImageChange(petImage, R.drawable.image4)
        }

        playButton.setOnClickListener {
            petHealth += 5
            petClean += 10
            petHunger += 5
            textHappy.setText(petHealth.toString())
            animateImageChange(petImage, R.drawable.image2)
        }


    }

    private fun animateImageChange(petImage: ImageView?, image3: Int) {

    }
}